using System;
using System.Collections.Generic;
using System.Text;

namespace MetaDataSample
{
    public class Dove : AbstractBird
    {
        public override void Sing()
        {
            Console.WriteLine("��ѱ� ���� �Ҹ�. ����?");
        }
    }
}
