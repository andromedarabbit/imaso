using System;
using System.Collections.Generic;
using System.Text;

namespace Expansion
{
    class Mockingbird: MetaDataSample.AbstractBird
    {
        public override void Sing()
        {
            Console.WriteLine("�޹��� ���� �Ҹ�. �޹�?");
        }
    }
}
