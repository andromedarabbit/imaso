using System;

namespace AIMLbot.Utils
{
    /// <summary>
    /// Used to determine the gender of things
    /// </summary>
    public enum Gender
    {
        Unknown = -1,
        Female = 0,
        Male = 1
    }
}