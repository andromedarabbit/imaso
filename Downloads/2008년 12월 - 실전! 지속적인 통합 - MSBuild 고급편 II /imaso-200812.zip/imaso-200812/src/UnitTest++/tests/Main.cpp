#include "../src/UnitTest++.h"
#include "../src/TestReporterStdout.h"


int main(int, char const *[])
{
    return UnitTest::RunAllTests();
}
