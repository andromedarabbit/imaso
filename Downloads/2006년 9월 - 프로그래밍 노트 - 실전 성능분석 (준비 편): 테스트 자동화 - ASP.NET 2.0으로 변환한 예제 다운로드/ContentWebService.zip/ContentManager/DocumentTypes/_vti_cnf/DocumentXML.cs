vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Jul 2001 18:53:04 -0000
vti_extenderversion:SR|4.0.2.4426
vti_nexttolasttimemodified:TR|20 Jul 2001 18:51:45 -0000
vti_author:SR|DENHAAG\\ppaul
vti_modifiedby:SR|DENHAAG\\ppaul
vti_timecreated:TR|20 Jul 2001 18:32:45 -0000
vti_filesize:IR|4863
vti_backlinkinfo:VX|
vti_cacheddtm:TX|20 Jul 2001 18:53:04 -0000
