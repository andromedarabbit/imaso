vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Jul 2001 22:03:17 -0000
vti_extenderversion:SR|4.0.2.4426
vti_nexttolasttimemodified:TR|20 Jul 2001 19:13:35 -0000
vti_author:SR|DENHAAG\\ppaul
vti_modifiedby:SR|DENHAAG\\ppaul
vti_timecreated:TR|20 Jul 2001 18:32:46 -0000
vti_filesize:IR|5973
vti_backlinkinfo:VX|
vti_cacheddtm:TX|22 Jul 2001 22:03:17 -0000
