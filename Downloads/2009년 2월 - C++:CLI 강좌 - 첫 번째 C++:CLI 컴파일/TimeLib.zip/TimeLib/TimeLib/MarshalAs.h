#pragma once
#include <msclr/marshal.h>
#include "TimeSpan.h"

namespace msclr
{
	namespace interop
	{
		using namespace System;

		template <>
		inline TimeSpan marshal_as<TimeSpan, NTimeSpan>(const NTimeSpan& nativeObj) 
		{
			return TimeSpan(nativeObj.Ticks());
		}

		inline NTimeSpan marshal_as( TimeSpan% managedObj) 
		{
			return NTimeSpan(managedObj.Ticks);
		}


		template<>
		ref class context_node<NTimeSpan*, TimeSpan> : public context_node_base
		{
		private:
			NTimeSpan* toPtr;
			marshal_context context;

		public:
			context_node(NTimeSpan*& toObject, TimeSpan fromObject)
			{
				// Conversion logic starts here
				toPtr = NULL;

				/*
				const char* nativeName;
				const char* nativeAddress;

				// Convert the name from String^ to const char*.
				System::String^ tempValue = fromObject->name;
				nativeName = context.marshal_as<const char*>(tempValue);

				// Convert the address from String^ to const char*.
				tempValue = fromObject->address;
				nativeAddress = context.marshal_as<const char*>(tempValue);
				*/

				toPtr = new NTimeSpan(fromObject.Ticks);
				
				toObject = toPtr;
			}

			~context_node()
			{
				this->!context_node();
			}

		protected:
			!context_node()
			{
				// When the context is deleted, it will free the memory
				// allocated for toPtr->name and toPtr->address, so toPtr
				// is the only memory that needs to be freed.
				if (toPtr != NULL) {
				   delete toPtr;
				   toPtr = NULL;
				}
			}
		};


	}
}