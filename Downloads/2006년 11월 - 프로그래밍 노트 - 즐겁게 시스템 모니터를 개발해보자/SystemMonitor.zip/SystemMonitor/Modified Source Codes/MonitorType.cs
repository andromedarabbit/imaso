using System;
using System.Collections.Generic;
using System.Text;

namespace SystemMonitor
{
	enum MonitorType
	{
		Persistent,
		Scheduled
	}
}
