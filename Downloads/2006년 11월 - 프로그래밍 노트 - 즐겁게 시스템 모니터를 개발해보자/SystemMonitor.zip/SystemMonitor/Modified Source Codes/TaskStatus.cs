using System;
using System.Collections.Generic;
using System.Text;

namespace SystemMonitor
{
	enum TaskStatus
	{
		Monitoring,
		Sleeping,
		Running
	}
}
