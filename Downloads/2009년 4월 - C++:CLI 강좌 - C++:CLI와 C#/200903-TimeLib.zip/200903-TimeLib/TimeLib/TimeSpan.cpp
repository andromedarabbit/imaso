#include "stdafx.h"
#include "TimeSpan.h"