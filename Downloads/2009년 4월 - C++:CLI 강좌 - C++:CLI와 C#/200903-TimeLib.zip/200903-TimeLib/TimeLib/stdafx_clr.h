#pragma once
#include "stdafx_common.h"