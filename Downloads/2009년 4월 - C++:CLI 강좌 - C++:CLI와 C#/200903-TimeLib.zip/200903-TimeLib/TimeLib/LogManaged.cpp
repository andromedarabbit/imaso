#include "stdafx_clr.h"
#include "LogManaged.h"