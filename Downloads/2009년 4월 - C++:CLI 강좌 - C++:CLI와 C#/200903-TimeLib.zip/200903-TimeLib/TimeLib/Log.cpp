#include "stdafx.h"
#include "Log.h"
